<!--Author-Arya-->
<?php

/**
 * Use an HTML form to create a new entry in the
 * users table.
 *
 */


if (isset($_POST['submit'])) {
    require "../config.php";
    require "../common.php";
	$Name=$_POST["Name"];
	$Course=$_POST["Course"];
	$Batch=$_POST["Batch"];
	$fromdate=$_POST["ldate"];
	$todate=$_POST["cdate"];
	$Reason=$_POST["Reason"];

       $sql=null;
       $hostname="localhost";
	   $username="root";
	   $password="";
	   $databaseName="try";
	   $connect=mysqli_connect($hostname,$username,$password,$databaseName);
	    $x=0;               //flag
        if(preg_match("/^[a-zA-Z -]+$/", $Name) === 0)     
		     {
			   echo " <br>Name is not valid";
			   $x++;
		     }
		if(is_numeric($Name))
			{
				echo "<br> Name cannot be numeric";
				$x++;
			}
	    if(is_numeric($Name))
			 {
				echo "Name cannot be numeric";
				$x++;
			 }
		if(empty($Course)) 
		{
			echo "Select Course";
			$x++;
		}
		if(empty($Batch)) 
		{
			echo "Select Batch";
			$x++;
		}
		if(empty($fromdate)) 
		{
			echo "Select Date";
			$x++;
		}
		if(empty($todate)) 
		{
			echo "Select Date";
			$x++;
		}
		if(empty($Reason)) 
		{
			echo "Enter Reason";
			$x++;
		}
		
		if($x<1)
		{
		
		$sql="INSERT INTO lea ( `name`, `course`, `batch`, `fromdate`, `todate`, `reason`) VALUES('$Name','$Course','$Batch','$fromdate','$todate','$Reason')";
		}
 if($connect->query($sql)=== TRUE) {
    echo "New record created successfully";
} else {
   echo "Error: " . $sql . "<br>" . $connect->error;
}
	}
?>
<script>
    function check()
    {
        var Name=document.forms["form"]["Name"].value;
        var Course=document.forms["form"]["Course"].value;
        var Batch=document.forms["form"]["Batch"].value;
		var ldate=document.forms["form"]["ldate"].value;
	    var cdate=document.forms["form"]["cdate"].value;
		var Reason=document.forms["form"]["Reason"].value;
		
        if(Name.value=="")
        {
            alert("Name Required");
            document.forms["form"]["Name"].focus();
				return false;
        }
        
        if(Course.value=="")
        {
            alert("Course Required");
            document.forms["form"]["Course"].focus();
            return false;
        }
		if(Batch.value=="")
        {
            alert("Batch Required");
            document.forms["form"]["Batch"].focus();
            return false;
        }
       if(ldate.value=="")
        {
            alert("Date Required");
            document.forms["form"]["ldate"].focus();
            return false;
        }       
		if(cdate.value=="")
        {
            alert("Date Required");
            document.forms["form"]["cdate"].focus();
            return false;
        }       
       if(Reason.value=="")
        {
            alert("Reason Required");
            document.forms["form"]["Reason"].focus();
            return false;
        }
	}
</script>

<?php require "templates/header.php"; ?>


<h2>Apply Leave</h2>

<form method="post" onsubmit="check" name="form">
    <label for="Name">Name</label>
    <input type="text" name="Name" id="Name">
	<label for="Course">Course</label>
	<select name="Course">
  <option value="select">Select</option>
  <option value="Jsd">JSD</option>
  <option value="Ui">UI</option>
  <option value="Fs">Fire & Safety</option>
  <option value="Ed">ED</option>
  </select>
	<label for="Batch">Batch</label>
	<select name="Batch">
  <option value="select">Select</option>
  <option value="2018">2018</option>
  <option value="2019">2019</option>
  <option value="2020">2020</option>
  <option value="2021">2021</option>
  </select><br>
    <label for="ldate">from Date</label>
	<input type="date" name="ldate">
    <label for="cdate">to Date</label>
	<input type="date" name="cdate">
    <label for="Reason">Reason</label>
    <textarea name="Reason" id="Reason"></textarea>
    <input type="submit" name="submit" value="Submit">
</form>


<!--Author-Ashish-->
<?php require "templates/header.php"; ?>
<?php

/**
 * Use an HTML form to create a new entry in the
 * users table.
 *
 */

if (isset($_POST['submit'])) {
    require "../config.php";
    require "../common.php";

    try  {
        $connection = new PDO($dsn, $username, $password, $options);
        
        $new_user = array(
            
            "Name"=>$_POST['name'],
			//"Dateofbirth"=>$_POST['dob'],
            "Email"=>$_POST['email'],
            "Mobile"=>$_POST['mob'],
			//"Gender"=>$_POST['gen'],
			"Address"=> $_POST['addr'],
			//"Doj"=>$_POST['doj'],
			//"Doc"=>$_POST['doc'],
            //"Qualification"  => $_POST['qual'],
			//"Username"=>$_POST['uname'],
			"Password"=>$_POST['pwd'],
			"Types"=>$_POST['type_id'],
			"rltn"=>$_POST['rltn']
			
			);
	
		//SERVER SIDE
		$x=0;
		 
		
			
			
			if(preg_match("/^[a-zA-Z -]+$/",$_POST['name'])===0)
			{
				echo "name is not entered <br>";
				$x++;
			}
			if($_POST['email']=="")
			{
				echo "Email is not entered <br>";
				$x++;
			}
			 if(filter_var($_POST['email'], FILTER_VALIDATE_EMAIL))
			{//
		    }
			
			else {
		
				echo "Email is not Valid <br>";
				$x++;
			}
			if($_POST['pwd']=="")
			{
				echo "password entered <br>";
				$x++;
			}
			
			if($_POST['mob']=="")
			{
				echo "enter the mobile no<br>";
				$x++;
			}
			 else if(!is_numeric($_POST['mob']))
			{
				echo"Invalid mobile number,Check it is number <br>";
				$x++;
			}
	      
			if($_POST['addr']=="")
			{
				echo "enter your address<br>";
				$x++;
			}
			if($_POST['rltn']=="")
			{
				echo "enter your rltn<br>";
				$x++;
			}
		$sql = "SELECT * FROM users WHERE email = :email";
        $statement= $connection->prepare($sql);
        $statement->bindValue(':email',$_POST['email']);
         $statement->execute();

		 if($row = $statement->fetch(PDO::FETCH_ASSOC)) 
		 {
			$usernameExists = 1;
		 } 
		 else 
		 {
			$usernameExists = 0;
		 }
		 $statement->closeCursor();
		 if ($usernameExists) 
		 {
		   echo "Email already Exist";
		   $x++;
		 }
        		  
		if($x<1)
		{
        $sql = sprintf(
                "INSERT INTO %s (%s) values (%s)",
                "users",
                implode(", ", array_keys($new_user)),
                ":" . implode(", :", array_keys($new_user))
        );
        
		
        $statement = $connection->prepare($sql);
        $statement->execute($new_user);
		}
		else
		{
			echo "ENTERED DETAILS ARE INCORRECT";
		}
		 
	}
	catch(PDOException $error) {
        echo $sql . "<br>" . $error->getMessage();
    } 
	
	
}

?>



<?php if (isset($_POST['submit']) && $statement) { ?>
    <blockquote><?php echo $_POST['name']; ?> successfully added.</blockquote>
<?php } ?> 


<script>
    //CLIENT SIDE

function validate()
{
	
	var name=document.forms["register"]["name"].value;
	if(name=="")
	{
		alert("Enter your Name");
		document.forms["register"]["name"].focus();
		return false;
	}
	
	var eml=document.forms["register"]["email"].value;
	var atposition=eml.indexOf("@");  
	var dotposition=eml.lastIndexOf(".");  
	if(eml=="")
	{
		alert("Enter your email");
		document.forms["register"]["email"].focus();
		return false;
	}
	if (atposition<1 || dotposition<atposition+2 || dotposition+2>=eml.length)
	{
		alert("please check the format of email joe@gmail.com");
		document.forms["register"]["email"].focus();
		return false;
	}
	var mob = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
     if((inputtxt.value.match(mob))
        {
			alert("invalid phone number");
			document.forms["register"]["email"].focus();
        return false;
		}
	  else if(mob=="")
	{
	 	alert("Enter your Mobile no");
		document.forms["register"]["mob"].focus();
		return false;
	}
	var pass=document.forms["register"]["pwd"].value;
	if(pass=="")
	{
		alert("Enter your password");
		document.forms["register"]["pwd"].focus();
		return false;
	}
	
	var address=document.forms["register"]["pwd"].value;
	if(address=="")
	{
		alert("Enter your password");
		document.forms["register"]["pwd"].focus();
		return false;
	}
	var rl=document.forms["register"]["rltn"].value;
	if(rl=="")
	{
		alert("Enter your rltn");
		document.forms["register"]["rltn"].focus();
		return false;
	}
	
return true;
	

}
</script>

<center>
<div class="reg">
<h2>Parent Registration</h2>
<form method="post" name="register" onsubmit="return validate()">
    
    <label for="name"> Name</label>
    <input type="text" name="name" id="name">
	<label for="email">Email</label>
    <input type="text" name="email" id="email">
	<label for="mobile">Mobile</label>
    <input type="mobile" name="mob" id="mob">
	<label for="address">Address</label>
    <input type="text" name="addr" id="addr">
    <label for="password">Password</label>
	<input type="password" name="pwd" id="password">
	 <label for="Type">Type</label>
	
	 <input type="radio" name="type_id" id="type_id" value="student">Student
	<input type="radio" name="type_id" id="type_id" value="parent">Parent
	<input type="radio" name="type_id" id="type_id" value="teacher">Teacher
	<br><br>
	<label for="rel">Relation</label>
	<input type="text" name="rltn" id="rltn"><br><br>
    <input type="submit" name="submit" value="Submit">
</form>


</div>
</center>
<?php require "templates/footer.php";?>
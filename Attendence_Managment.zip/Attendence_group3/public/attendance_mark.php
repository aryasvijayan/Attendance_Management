<!--Author-Asna-->
<style>
    <!-- table,td,th
    {
		margin:10px auto;
		border:2px solid #663300;
        border-collapse:collapse; 
        text-align:center;
        padding:20px;
        background:rgba(0,0,0,0.5);
		color:white;
    }
  th
    {
		background-color: black;
		text-align:center;
	}
h2  {
	  text-align:center;
	  color:tomato;
	}
a   {
	 text-decoration:none;
	 color:white;
	} --->
 </style>



		
<?php 
        require "../config.php";
    require "../common.php";
	
	    $connection = new PDO($dsn, $username, $password, $options);
       //contains PDO connection script
	try
	{
		//echo $name=$_POST['name'];
		foreach($_POST['attendance'] as $key =>$val)
		{ 
          		
           echo  $studentid = $key;
           echo  $status = $val;
		   $statement = $connection->prepare("INSERT INTO `attendence` 
		   (`id`,`fornoon`)
			               VALUES(?,?)");
           $statement->execute(array($key, $val));
		   
		}
	
	
		
	}
		
	catch(PDOException $error)
    {
       echo $statement . "<br>" . $error->getMessage();
    }   
?>
<!--Author-Asna-->
<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Simple Database App</title>

	<link rel="stylesheet" href="css/style.css">
</head>

<body class="bg">
<div class="menubar" >
<ul>
<li><a href= "index.php">Home</a></li>
<li><a href= "log.php">Login</a></li>
<li><a href= "reglist.php">Registration</a></li>

<li><a href="#">Contact us</a></li>
 </ul> 
</div>

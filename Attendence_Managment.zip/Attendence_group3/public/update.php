<!--Author-sebastian-->
<?php

/**
 * List all users with a link to edit
 */

require "../config.php";
require "../common.php";

try {
  $connection = new PDO($dsn, $username, $password, $options);

  $sql = "SELECT * FROM users";

  $statement = $connection->prepare($sql);
  $statement->execute();

  $result = $statement->fetchAll();
} catch(PDOException $error) {
  echo $sql . "<br>" . $error->getMessage();
}
?>
<?php require "templates/header.php"; ?>
        
<h2>Update users</h2>

<table>
    <thead>
        <tr>
            <th>Id</th>
             <th>Name</th>
                    <th>Date of birth</th>
                    <th>Email </th>
<th>Mobile</th>
<th>Gender</th>
<th>Address</th>
                    <th>Doj</th>
<th>Doc</th>
                    <th>Qualification</th>
<th>Username</th>
                    <th>Type</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($result as $row) : ?>
        <tr>
		<td><?php echo escape($row["id"]); ?></td>
             <td><?php echo escape($row["Name"]); ?></td>
                <td><?php echo escape($row["Dateofbirth"]); ?></td>
                <td><?php echo escape($row["Email"]); ?></td>
                <td><?php echo escape($row["Mobile"]); ?></td>
                <td><?php echo escape($row["Gender"]); ?></td>
                <td><?php echo escape($row["Address"]); ?></td>
				<td><?php echo escape($row["Doj"]); ?></td>
				<td><?php echo escape($row["Doc"]); ?></td>
                <td><?php echo escape($row["Qualification"]); ?> </td>
<td><?php echo escape($row["Username"]); ?> </td>
<td><?php echo escape($row["Types"]); ?> </td>
            <td><a href="n.php?id=<?php echo escape($row["id"]); ?>">Edit</a></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<a href="index.php">Back to home</a>

<?php require "templates/footer.php"; ?>
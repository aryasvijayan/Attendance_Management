<?php require "templates/header.php"; ?>
<?php
//session_start();
//$_SESSION['email']=$_POST["email"];
if (isset($_POST['submit'])) {
    
        
        require "../config.php";
        require "../common.php";
		
        try  {
        $connection = new PDO($dsn, $username, $password, $options);
        
         
        $sql = "SELECT * 
                        FROM users
                        WHERE Email= :email and Password= :pwd";

        $email = $_POST['email'];
        $pass = $_POST['pwd'];
        $statement = $connection->prepare($sql);
        $statement->bindParam(':email', $email, PDO::PARAM_STR);
		 $statement->bindParam(':pwd', $pass, PDO::PARAM_STR);
        $statement->execute();
		
        
         if($row = $statement->fetch(PDO::FETCH_ASSOC)) 
		 {
			$usernameExists = 1;
		 } 
		 else 
		 {
			$usernameExists = 0;
		 }
		 $statement->closeCursor();
		 if ($usernameExists) 
		 {
			 
			 
		   echo "Login Sucessfully ";
		   //echo $_SESSION['email'];
		    $u=$row['Types'];
		   if($u=="stu")
		   {
			echo  "<script> window.location='profile.php';
			  </script>";
		   }
			  else if($u=="tea")
			  {
		   echo  "<script> window.location='teacherprofile.php';
			  </script>";
		 }
		   else if($u=="adm")
			  {
		   echo  "<script> window.location='admindash.php';
			  </script>";
		 }
		 }
		 else
		 {
			 echo "Incorrect email and password"; 
		 } 
		
			
			 
		 	 

    } catch(PDOException $error) {
        echo $sql . "<br>" . $error->getMessage();
    }
}

?>
		

<?php if (isset($_POST['login']) && $statement) { ?>
    <blockquote><?php echo $_POST['name']; ?> successfully added.</blockquote>
<?php } ?>

<script>
function validate()
{
    var eml=document.forms["register"]["email"].value;
	var atposition=eml.indexOf("@");  
	var dotposition=eml.lastIndexOf(".");  
	if(eml=="")
	{
		alert("Enter your email");
		document.forms["register"]["email"].focus();
		return false;
	}
	if (atposition<1 || dotposition<atposition+2 || dotposition+2>=eml.length)
	{
		alert("please check the format of email joe@gmail.com");
		document.forms["register"]["email"].focus();
		return false;
	}
	var pwd=document.forms["register"]["pwd"].value;
	if(pwd=="")
	{
		alert("Enter your password");
		document.forms["register"]["pwd"].focus();
		return false;
	}
	return true;
	}
	
</script>


<center>
<div class="log">
<h2>Login</h2>
<br>
<br>
<form method="post"  onsubmit="return validate()" name="register" >
<table>
<tr>

</tr>
<tr>
    <td><label for="email">Email Address</label></td>
    <td><input type="text" name="email" id="email"></td>
</tr>
<tr>
    <td><label for="pass">Password</label></td>
    <td><input type="password" name="pwd" id="pwd"></td>
</tr>
</table>
<br>
<input type="submit" name="cancel" value="Cancel" class="button">
<input type="submit" name="submit" value="Login" class="button" href="profile.php">
</div>
</center>
</form>

<?php require "templates/footer.php"; ?>
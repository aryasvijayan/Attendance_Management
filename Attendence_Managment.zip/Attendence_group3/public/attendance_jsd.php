<!--Author-ASHISH-->
 <style>
    table,td,th
    {
		margin:10px auto;
		border:2px solid rgba(31, 97, 141,0.4);
        border-collapse:collapse; 
        text-align:center;
        padding:20px;
       <!-- background:rgba(0,0,0,0.1);--->
		color:white;
		margin-bottom:50px;
    }
  th
    {
		background-color:white;
		text-align:center;
	}
h2  {
	  text-align:center;
	  color:tomato;
	}
a   {
	 text-decoration:none;
	 color:white;
	} 
 </style>
 <?php require "templates/header.php"; ?>
 <?php
     require "../config.php";
    require "../common.php";
	$connection = new PDO($dsn, $username, $password, $options);
	
        $sql= "Select * from users where Class='JSD'";
			$statement = $connection->prepare($sql);
            $statement->execute();
            $result = $statement->fetchAll();
			if ($result && $statement->rowCount() > 0)
		    {
?>
          <h2>Results</h2>
         
       
	   <table>
            <thead>
			
			        <!---Details from pop form   -->
			<form action="attendance_mark.php"  method="post">  
				
			        <!---table details/fields-->
            <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Mark Attendence</th>
            </tr>	
				
            </thead>
			
            <tbody>
<?php	   
            foreach ($result as $row) { 
?>
            <tr>
            <td><?php echo ($row["id"]); ?>
			    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
			</td>
            <td><?php echo ($row["Name"]); ?>
			    <input type="hidden" name="name" value="<?php echo $row['Name']; ?>">
			</td>			
		    <td>
		     Present<input required type="radio" name="attendance[<?php echo $row['id'] ?>]" value="Present" checked>
             Absent<input required type="radio" name="attendance[<?php echo $row['id']; ?>]" value="Absent">
            </td>
            </tr>
<?php   } 
?>
            <tr>
            <td colspan="6">
			  <a href="attendance_mark.php">
			    <input type="submit" name="attendanceData" value="Save">
			  </a>
			</td>
            </tr>
        </tbody>
    </table>

	</form>
<?php  
	}?>
	<?php require "templates/footer.php"; ?>
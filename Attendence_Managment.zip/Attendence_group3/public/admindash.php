<!--Author-Vishu-->
<?php require "templates/header.php"; ?>
<h1><center>WELCOME ADMIN</div></h1></center>
<div class="addash">
<ul>
<li><center><a href= "ad_st_det.php">View Student</a></li>
<li><center><a href= "ad_tr_det.php">View Teacher</a></li>
<li><center><a href= "ad_pr_det.php"> View Parent</a></li>
<li><center><a href= "delete.php">Remove</a></li>
<li><center><a href= "update.php">Update</a></li>
<li><center><a href= "#.php">Add Notification</a></li>
</ul>
</div>
<?php require "templates/footer.php"; ?>
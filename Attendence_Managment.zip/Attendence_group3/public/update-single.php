<!--Author-Ashish-->
<?php

/**
 * Use an HTML form to edit an entry in the
 * users table.
 *
 */

require "../config.php";
require "../common.php";

if (isset($_POST['submit'])) {


  try {
    $connection = new PDO($dsn, $username, $password, $options);

    $new_user = array(
            $Id=$_POST['id'],
            $name=$_POST['name'],
			$dateofbirth=$_POST['dob'],
            $email=$_POST['email'],
            $mobile=$_POST['mob'],
			$gender=$_POST['gen'],
			$address=$_POST['addr'],
			$doj=$_POST['doj'],
			$doc=$_POST['doc'],
            $qualification=$_POST['qual'],
			$username=$_POST['uname'],
			$types=$_POST['type_id'],
			$class=$_POST['class']
        );

    
		
		$sql = "UPDATE users SET Name=?,  Dateofbirth=?, Email=?, Mobile=?, Gender=?, Address=?, Doj=?, Doc=?, Qualification=?, Username=?,  Types=?, Class=? WHERE id=?";
			$statement= $connection->prepare($sql);
			$statement->execute($new_user);
  } catch(PDOException $error) {
      echo $sql . "<br>" . $error->getMessage();
  }
}

  
if (isset($_GET['id'])) {
  try {
    $connection = new PDO($dsn, $username, $password, $options);
    $id = $_GET['id'];

    $sql = "SELECT * FROM users WHERE id = :id";
    $statement = $connection->prepare($sql);
    $statement->bindValue(':id', $id);
    $statement->execute();
    
    $result = $statement->fetch(PDO::FETCH_ASSOC);
  } catch(PDOException $error) {
      echo $sql . "<br>" . $error->getMessage();
  }
} else {
    echo "Something went wrong!";
    exit;
}
?>

<?php require "templates/header.php"; ?>

<?php if (isset($_GET['submit']) && $statement) : ?>
	<blockquote><?php echo escape($_POST['name']); ?> successfully updated.</blockquote>
<?php endif; ?>

<h2>Edit a user</h2>

<form method="POST"">
    
    <?php foreach ($result as $key => $value) : ?>
	
    <label for="<?php echo $key; ?>"><?php echo ucfirst($key); ?></label>
	<input type="text" name="<?php echo $key; ?>" id="<?php echo $key; ?>" value="<?php echo escape($value); ?>" <?php echo ($key === 'id' ? 'readonly' : null); ?>>
    <?php endforeach; ?> 
    <input type="submit" name="submit" value="Submit">
</form>

<a href="index.php">Back to home</a>

<?php require "templates/footer.php"; ?>

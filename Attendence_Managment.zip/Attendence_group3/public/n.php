<!--Author-Arya-->
<?php
// including the database connection file
require "../config.php";
require "../common.php";
 
if(isset($_POST['update']))
{    
            $Id=$_POST['id'];
            $Name=$_POST['name'];
			$Dateofbirth=$_POST['dob'];
            $Email=$_POST['email'];
            $Mobile=$_POST['mob'];
			$Gender=$_POST['gen'];
			$Address=$_POST['addr'];
			$Doj=$_POST['doj'];
			$Doc=$_POST['doc'];
            $Qualification=$_POST['qual'];
			$Username=$_POST['uname'];
			$Password=$_POST['pwd'];
			$Types=$_POST['type_id'];
			$Class=$_POST['class']	;
    
 
       
        $sql = "UPDATE users SET Id=:Id, Name=:Name, Dateofbirth=:Dateofbirth, Email=:Email Mobile=:Mobile, Gender=:Gender, Address=:Address,Doj=:Doj,Doc=:Doc,Qualification=:Qualification,Username=:Username,Password=:Password,Types=:Types,Class=:Class WHERE id=:id";
        $statement = $connection->prepare($sql);
        $statement->bindparam(':Id', $Id);        
        $statement->bindparam(':Name', $Name);
       $statement->bindparam(':Dateofbirth',$Dob );
        $statement->bindparam(':Email',$Email);
        $statement->bindparam(':Mobile', $Mobile);
		 $statement->bindparam(':Gender', $Gender);
        $statement->bindparam(':Address', $Address);
        $statement->bindparam(':Doj', $Doj);
        $statement->bindparam(':Doc', $Doc);
		 $statement->bindparam(':Qualification', $Qualification);
        $statement->bindparam(':Username', $Username);
        $statement->bindparam(':Password', $Password);
        $statement->bindparam(':Types', $Types);
		 $statement->bindparam(':Class', $Class);
        $statement->execute();
        
        // Alternative to above bindparam and execute
        // $query->execute(array(':id' => $id, ':name' => $name, ':email' => $email, ':age' => $age));
                
        //redirectig to the display page. In our case, it is index.php
        //header("Location: index.php");
    }

?>
<?php
//getting id from url
if (isset($_POST['id'])) 
{
//selecting data associated with this particular id
$sql = "SELECT * FROM users WHERE id=:id";
$statement= $connection->prepare($sql);
        $statement->bindValue(':Email',$_POST['email']);
         $statement->execute(array(':id' => $id));

 
while($result = $statement->fetch(PDO::FETCH_ASSOC))
{
    
            $Name=$_POST['name'];
			$Dateofbirth=$_POST['dob'];
            $Email=$_POST['email'];
            $Mobile=$_POST['mob'];
			$Gender=$_POST['gen'];
			$Address=$_POST['addr'];
			$Doj=$_POST['doj'];
			$Doc=$_POST['doc'];
            $Qualification=$_POST['qual'];
			$Username=$_POST['uname'];
			$Password=$_POST['pwd'];
			$Types=$_POST['type_id'];
			$Class=$_POST['class'];	
}
}
?>
    
    <form  method="post" action="n.php">
        <table border="0">
		 <thead>
		 <tr>
		 <th>Name</th>
	<th>DOB</th>
    <th>Email Address</th>
	 <th>Mobile</th>
	 <th>Gender</th>
    <th>Address</th>
	<th>Date of joining</th>
	<th>Date of Completion</th>
    <th>Qualification</th>
	<th>Username</th>
	<th>Password</th>
	<th>Type</th>
	<th>Class</th>
	</tr>
	</thead>
	<tbody>
	<td><input type="hidden" name="id" value="<?php echo $_POST['id'];?>"></td>
	 <td><input type="text" name="name" id="name" value="<?php echo $_POST['name'];?>"></td>
	 <td><input type="date" name="dob" id="dob" value="<?php echo $_POST['dob'];?>"></td>
	 <td><input type="text" name="email" id="email" value="<?php echo $_POST['email'];?>"></td>
	 <td><input type="text" name="mob" id="mob" value="<?php echo $_POST['id'];?>"></td>
	 <td>Male
    <input type="radio" name="gen" id="gen" value="<?php echo $_POST['id'];?>">
	Female</td>
	<td><input type="radio" name="gen" id="gen" value="<?php echo $_POST['id'];?>"></td>
	<td><input type="text" name="addr" id="addr" value="<?php echo $_POST['id'];?>"></td>
	 <td><input type="text" name="doj" id="doj" value="<?php echo $_POST['id'];?>"></td>
	 <td><input type="text" name="doc" id="doc" value="<?php echo $_POST['id'];?>"></td>
	  <td><input type="text" name="qual" id="qual" value="<?php echo $_POST['id'];?>"></td>
	 <td><input type="text" name="uname" id="uname" value="<?php echo $_POST['id'];?>"></td>
	  <td><input type="text" name="pwd" id="pwd" value="<?php echo $_POST['id'];?>"></td>
	 <td><input type="radio" name="type_id" id="type_id" value="student">Student
	<input type="radio" name="type_id" id="type_id" value="parent">Parent
	<input type="radio" name="type_id" id="type_id" value="teacher">Teacher
	<input type="radio" name="type_id" id="type_id" value="admin">admin
	</td>
	 <td><select name="class">
    <option value="JSD">JSD1</option>
	<option value="JSD2">JSD2</option>
	<option value="UI">UI</option>
	<option value="ED">ED</option>
	<option value="FS">FS</option></td>
	</tbody>
           
                <td><input type="hidden" name="id" value=<?php echo $_POST['id'];?>></td>
                <td><input type="submit" name="update" value="Update"></td>
            </tr>
        </table>
    </form>
</body>
</html>
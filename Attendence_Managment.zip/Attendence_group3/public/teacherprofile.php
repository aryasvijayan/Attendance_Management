<!--Author-Florance-->
<?php require "templates/header.php"; ?>
<h1><center> WELCOME Teacher</center></h1>
<div class="dash">
<ul>
<li><center><a href="att_main.php">Mark Attendence</a></li>
<li><center><a href="viewteacher.php">View Leave</a></li>
<li><center><a href="parentr.php"> Enquiries</a></li>
<li><center><a href="parentr.php">Notifications</a></li>
</ul>
</div>
<?php require "templates/footer.php"; ?>
<?php require "templates/header.php"; ?>
<!--Author-Arya-->
<div class="dash">
<ul>
<li><center><a href= "student.php">Student</a></li>
<li><center><a href= "teacher.php">Teacher</a></li>
<li><center><a href= "parentr.php">Parent</a></li>
</ul>
</div>
<?php require "templates/footer.php"; ?>
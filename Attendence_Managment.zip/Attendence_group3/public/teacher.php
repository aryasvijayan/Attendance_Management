<!--Author-ebin-->
<?php require "templates/header.php"; ?>
<?php

/**
 * Use an HTML form to create a new entry in the
 * users table.
 *
 */


if (isset($_POST['submit'])) {
    require "../config.php";
    require "../common.php";

    try  {
        $connection = new PDO($dsn, $username, $password, $options);
        
        $new_user = array(
            
            "Name"=>$_POST['name'],
			"Dateofbirth"=>$_POST['dob'],
            "Email"=>$_POST['email'],
            "Mobile"=>$_POST['mob'],
			"Gender"=>$_POST['gen'],
			"Address"=> $_POST['addr'],
			//"Doj"=>$_POST['doj'],
			//"Doc"=>$_POST['doc'],
            "Qualification"  => $_POST['qual'],
			"Username"=>$_POST['uname'],
			"Password"=>$_POST['pwd'],
			"Types"=>$_POST['type_id']
        );
		//SERVER SIDE
		$x=0;
		 
		
			if($_POST['uname']=="")
			{
				echo "Username is not entered <br>";
				$x++;
			}
	       
			
			if(preg_match("/^[a-zA-Z -]+$/",$_POST['name'])===0)
			{
				echo "name is not entered <br>";
				$x++;
			}
			if($_POST['email']=="")
			{
				echo "Email is not entered <br>";
				$x++;
			}
			 if(filter_var($_POST['email'], FILTER_VALIDATE_EMAIL))
			{//
		    }
			
			else {
		
				echo "Email is not Valid <br>";
				$x++;
			}
			if($_POST['pwd']=="")
			{
				echo "password entered <br>";
				$x++;
			}
			
			if($_POST['mob']=="")
			{
				echo "enter the mobile no<br>";
				$x++;
			}
			 else if(!is_numeric($_POST['mob']))
			{
				echo"Invalid mobile number,Check it is number <br>";
				$x++;
			}
	        if($_POST['dob']=="")
			{
				echo "enter the date of birth<br>";
				$x++;
			}
			 if($_POST['gen']=="")
			{
				echo "enter the date of bith<br>";
				$x++;
			}
			if(preg_match("/^[a-zA-Z -]+$/",$_POST['qual'])===0)
			{
				echo "Enter your Qualification <br>";
				$x++;
			}
			if($_POST['addr']=="")
			{
				echo "enter your address<br>";
				$x++;
			}
		$sql = "SELECT * FROM users WHERE Username = :uname";
        $statement= $connection->prepare($sql);
        $statement->bindValue(':uname',$_POST['uname']);
         $statement->execute();

		 if($row = $statement->fetch(PDO::FETCH_ASSOC)) 
		 {
			$usernameExists = 1;
		 } 
		 else 
		 {
			$usernameExists = 0;
		 }
		 $statement->closeCursor();
		 if ($usernameExists) 
		 {
		   echo "Username already Exist";
		   $x++;
		 }	
			
      
		$sql = "SELECT * FROM users WHERE email = :email";
        $statement= $connection->prepare($sql);
        $statement->bindValue(':email',$_POST['email']);
         $statement->execute();

		 if($row = $statement->fetch(PDO::FETCH_ASSOC)) 
		 {
			$usernameExists = 1;
		 } 
		 else 
		 {
			$usernameExists = 0;
		 }
		 $statement->closeCursor();
		 if ($usernameExists) 
		 {
		   echo "Email already Exist";
		   $x++;
		 }
        		  
		if($x<1)
		{
        $sql = sprintf(
                "INSERT INTO %s (%s) values (%s)",
                "users",
                implode(", ", array_keys($new_user)),
                ":" . implode(", :", array_keys($new_user))
        );
        
		
        $statement = $connection->prepare($sql);
        $statement->execute($new_user);
		}
		else
		{
			echo "ENTERED DETAILS ARE INCORRECT";
		}
		 
	}
	catch(PDOException $error) {
        echo $sql . "<br>" . $error->getMessage();
    } 
	
	
}

?>



<?php if (isset($_POST['submit']) && $statement) { ?>
    <blockquote><?php echo $_POST['name']; ?> successfully added.</blockquote>
	
<?php } ?>



<script>
//CLIENT SIDE

function validate()
{
	var Uname=document.forms["register"]["uname"].value;
	if(Uname=="")
	{
	 	alert("Enter your Username");
		document.forms["register"]["uname"].focus();
		return false;
	}
	
	var name=document.forms["register"]["name"].value;
	if(name=="")
	{
		alert("Enter your Name");
		document.forms["register"]["name"].focus();
		return false;
	}
	
	var eml=document.forms["register"]["email"].value;
	var atposition=eml.indexOf("@");  
	var dotposition=eml.lastIndexOf(".");  
	if(eml=="")
	{
		alert("Enter your email");
		document.forms["register"]["email"].focus();
		return false;
	}
	if (atposition<1 || dotposition<atposition+2 || dotposition+2>=eml.length)
	{
		alert("please check the format of email joe@gmail.com");
		document.forms["register"]["email"].focus();
		return false;
	}
	var mob = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
     if((inputtxt.value.match(mob))
        {
			alert("invalid phone number");
			document.forms["register"]["email"].focus();
        return false;
		}
	  else if(mob=="")
	{
	 	alert("Enter your Mobile no");
		document.forms["register"]["mob"].focus();
		return false;
	}
	var pass=document.forms["register"]["pwd"].value;
	if(pass=="")
	{
		alert("Enter your password");
		document.forms["register"]["pwd"].focus();
		return false;
	}
	var gen=document.forms["register"]["gen"].value;
	if(gen=="")
	{
		alert("Enter your gender");
		document.forms["register"]["gen"].focus();
		return false;
	}
	var dob=document.forms["register"]["dob"].value;
	if(dob=="")
	{
		alert("Enter your date of birth");
		document.forms["register"]["dob].focus();
		return false;
	}
	var address=document.forms["register"]["pwd"].value;
	if(address=="")
	{
		alert("Enter your password");
		document.forms["register"]["pwd"].focus();
		return false;
	}
return true;
	

}
</script>

<center>
<div class="reg">
<h2>Teacher Registration</h2>
<table>
<form method="post" onsubmit="return validate()" name="register">
    <label for="text">Name</label>
    <input type="text" name="name" id="name" class="fld">
	<label for="Date of birth">DOB</label>
    <input type="date" name="dob" id="dob">
    <label for="Email">Email Address</label>
    <input type="text" name="email" id="email">
	 <label for="Mobile">Mobile</label>
    <input type="text" name="mob" id="mob">
	<br><br>
	 Male
    <input type="radio" name="gen" id="gen" value="male">
	Female
	<input type="radio" name="gen" id="gen" value="female"><br><br>
    <label for="Address">Address</label>
    <input type="text" name="addr" id="addr">
	<label for="Qualification">Qualification</label>
    <input type="text" name="qual" id="qual">
	<label for="Username">Username</label>
    <input type="text" name="uname" id="uname">
	<label for="Password">Password</label>
    <input type="text" name="pwd" id="pwd">
	<label for="Type">Type</label>
    <input type="radio" name="type_id" id="type_id" value="student">Student
	<input type="radio" name="type_id" id="type_id" value="parent">Parent
	<input type="radio" name="type_id" id="type_id" value="teacher">Teacher
	<br><br>
    <input type="submit" name="submit" value="Submit">
</form>

</table>
</div>
</center>
<?php require "templates/footer.php"; ?>


<!--Author-Asna-->
<?php require "templates/header.php"; ?>

<?php

 require "../config.php";
    require "../common.php";
if($_SESSION['email']=$_POST["email"])
{
	echo $_SESSION['email'];
	
}

?>
</div>
<h1><center> WELCOME STUDENT</center></h1>
<div class="dash">
<ul>
<li><center><a href= "viewstudent.php">View Attendence</a></li>
<li><center><a href= "leave form.php">Apply Leave</a></li>
<li><center><a href= "n.php">Update</a></li>
<li><center><a href= "viewprofile.php">View Profile</a></li>
</ul>
</div>
<?php require "templates/footer.php"; ?>


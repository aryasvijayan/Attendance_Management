-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 01, 2020 at 04:35 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `try`
--

-- --------------------------------------------------------

--
-- Table structure for table `att`
--

CREATE TABLE `att` (
  `Name` varchar(40) DEFAULT NULL,
  `afternoon` varchar(40) DEFAULT NULL,
  `fornoon` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `att`
--

INSERT INTO `att` (`Name`, `afternoon`, `fornoon`) VALUES
('arya', 'Present', 'Absent'),
(NULL, NULL, NULL),
(NULL, NULL, NULL),
(NULL, NULL, NULL),
(NULL, NULL, NULL),
('name', 'Present', 'Present'),
('Rohit', 'Present', 'Absent'),
('Rohit', 'Present', 'Absent'),
('Rohit', 'Present', 'Absent'),
(NULL, 'Present', 'Absent'),
(NULL, NULL, NULL),
(NULL, NULL, NULL),
('name', 'Present', 'Absent'),
(NULL, 'Present', 'Absent'),
(NULL, NULL, NULL),
(NULL, NULL, NULL),
(NULL, 'Present', 'Absent'),
(NULL, NULL, NULL),
(NULL, 'Present', 'Absent'),
(NULL, 'Present', 'Absent'),
('$_POST[\'name\']', 'Present', 'Absent'),
('', 'Present', 'Absent'),
('name', 'Present', 'Absent'),
('name', 'Present', 'Absent'),
('name', 'Present', 'Absent'),
('name', 'Present', 'Absent'),
('name', 'Present', 'Present'),
('Rohit', 'Present', 'Present'),
(NULL, NULL, NULL),
(NULL, NULL, NULL),
('Rohit', 'Present', 'Absent'),
(NULL, NULL, NULL),
('Rohit', 'Present', 'Absent'),
(NULL, 'Present', 'Absent'),
(NULL, 'Present', 'Absent'),
(NULL, 'Present', 'Absent'),
(NULL, 'Present', 'Absent'),
(NULL, 'Present', 'Absent'),
('Rohit', 'Present', 'Absent'),
('Vishnu Priya', NULL, NULL),
('abi', NULL, NULL),
('ebin', NULL, NULL),
('athira', NULL, NULL),
('Rohit', NULL, NULL),
('Vishnu Priya', NULL, NULL),
('abi', NULL, NULL),
('ebin', NULL, NULL),
('athira', NULL, NULL),
('Rohit', NULL, NULL),
('Vishnu Priya', NULL, NULL),
('abi', NULL, NULL),
('ebin', NULL, NULL),
('athira', NULL, NULL),
('Rohit', NULL, NULL),
('Rohit', 'Present', 'Absent');

-- --------------------------------------------------------

--
-- Table structure for table `att1`
--

CREATE TABLE `att1` (
  `name` varchar(40) DEFAULT NULL,
  `afternoon` varchar(40) DEFAULT NULL,
  `fornoon` varchar(40) DEFAULT NULL,
  `created_at` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `att1`
--

INSERT INTO `att1` (`name`, `afternoon`, `fornoon`, `created_at`) VALUES
('vishnupriya', 'Present', 'Absent', '2019-12-27'),
('vishnupriya', 'Present', 'Absent', '2019-12-27'),
('vishnupriya', 'Absent', 'Absent', '2019-12-27'),
('vishnupriya', 'Absent', 'Absent', '2019-12-27'),
('vishnupriya', 'Absent', 'Absent', '2019-12-27'),
('vishnupriya', 'Present', 'Absent', '2019-12-28'),
('vishnupriya', 'Present', 'Absent', '2019-12-28'),
('vishnupriya', 'Present', 'Absent', '2019-12-28'),
('vishnupriya', NULL, NULL, '2019-12-28'),
('arya', 'Present', 'Present', '2019-12-28'),
('arya', 'Present', 'Absent', '2019-12-28'),
('arya', NULL, NULL, '2019-12-28'),
('arya', NULL, NULL, '2019-12-28'),
('arya', 'Present', 'Absent', '2019-12-28'),
('vishnupriya', NULL, NULL, '2019-12-28'),
('vishnupriya', 'Present', 'Absent', '2019-12-28');

-- --------------------------------------------------------

--
-- Table structure for table `attendence`
--

CREATE TABLE `attendence` (
  `atten_id` int(11) UNSIGNED NOT NULL,
  `id` int(11) DEFAULT NULL,
  `batch_id` int(11) DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL,
  `tdate` varchar(80) NOT NULL,
  `afternoon` varchar(40) NOT NULL,
  `fornoon` varchar(40) NOT NULL,
  `status` varchar(40) NOT NULL,
  `sub_id` int(11) DEFAULT NULL,
  `created_by` varchar(80) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` varchar(80) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendence`
--

INSERT INTO `attendence` (`atten_id`, `id`, `batch_id`, `class_id`, `tdate`, `afternoon`, `fornoon`, `status`, `sub_id`, `created_by`, `created_at`, `updated_by`, `updated_at`) VALUES
(1, 5, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 07:01:32', '', '2020-01-01 07:01:32'),
(2, 5, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 07:05:32', '', '2020-01-01 07:05:32'),
(3, 5, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 07:07:36', '', '2020-01-01 07:07:36'),
(4, 5, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 07:07:54', '', '2020-01-01 07:07:54'),
(5, 5, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 07:16:09', '', '2020-01-01 07:16:09'),
(6, 7, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 07:16:09', '', '2020-01-01 07:16:09'),
(7, 11, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 07:16:09', '', '2020-01-01 07:16:09'),
(8, 13, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 07:16:10', '', '2020-01-01 07:16:10'),
(9, 15, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 07:16:10', '', '2020-01-01 07:16:10'),
(10, 5, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 07:30:20', '', '2020-01-01 07:30:20'),
(11, 7, NULL, NULL, '', '', 'Absent', '', NULL, '', '2020-01-01 07:30:20', '', '2020-01-01 07:30:20'),
(12, 11, NULL, NULL, '', '', 'Absent', '', NULL, '', '2020-01-01 07:30:20', '', '2020-01-01 07:30:20'),
(13, 13, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 07:30:20', '', '2020-01-01 07:30:20'),
(14, 15, NULL, NULL, '', '', 'Absent', '', NULL, '', '2020-01-01 07:30:20', '', '2020-01-01 07:30:20'),
(15, 5, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 07:33:40', '', '2020-01-01 07:33:40'),
(16, 7, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 07:33:40', '', '2020-01-01 07:33:40'),
(17, 11, NULL, NULL, '', '', 'Absent', '', NULL, '', '2020-01-01 07:33:40', '', '2020-01-01 07:33:40'),
(18, 13, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 07:33:40', '', '2020-01-01 07:33:40'),
(19, 15, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 07:33:40', '', '2020-01-01 07:33:40'),
(20, 5, NULL, NULL, '', '', 'Absent', '', NULL, '', '2020-01-01 08:14:09', '', '2020-01-01 08:14:09'),
(21, 7, NULL, NULL, '', '', 'Absent', '', NULL, '', '2020-01-01 08:14:09', '', '2020-01-01 08:14:09'),
(22, 11, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 08:14:09', '', '2020-01-01 08:14:09'),
(23, 13, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 08:14:09', '', '2020-01-01 08:14:09'),
(24, 15, NULL, NULL, '', '', 'Absent', '', NULL, '', '2020-01-01 08:14:09', '', '2020-01-01 08:14:09'),
(25, 5, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 08:21:21', '', '2020-01-01 08:21:21'),
(26, 7, NULL, NULL, '', '', 'Absent', '', NULL, '', '2020-01-01 08:21:21', '', '2020-01-01 08:21:21'),
(27, 11, NULL, NULL, '', '', 'Absent', '', NULL, '', '2020-01-01 08:21:21', '', '2020-01-01 08:21:21'),
(28, 13, NULL, NULL, '', '', 'Absent', '', NULL, '', '2020-01-01 08:21:21', '', '2020-01-01 08:21:21'),
(29, 15, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 08:21:21', '', '2020-01-01 08:21:21'),
(30, 16, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 09:46:16', '', '2020-01-01 09:46:16'),
(31, 17, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 09:46:16', '', '2020-01-01 09:46:16'),
(32, 18, NULL, NULL, '', '', 'Absent', '', NULL, '', '2020-01-01 09:46:16', '', '2020-01-01 09:46:16'),
(33, 19, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 09:46:16', '', '2020-01-01 09:46:16'),
(34, 16, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 09:47:50', '', '2020-01-01 09:47:50'),
(35, 17, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 09:47:50', '', '2020-01-01 09:47:50'),
(36, 18, NULL, NULL, '', '', 'Absent', '', NULL, '', '2020-01-01 09:47:50', '', '2020-01-01 09:47:50'),
(37, 19, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 09:47:50', '', '2020-01-01 09:47:50'),
(38, 16, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 09:48:41', '', '2020-01-01 09:48:41'),
(39, 17, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 09:48:41', '', '2020-01-01 09:48:41'),
(40, 18, NULL, NULL, '', '', 'Absent', '', NULL, '', '2020-01-01 09:48:41', '', '2020-01-01 09:48:41'),
(41, 19, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 09:48:41', '', '2020-01-01 09:48:41'),
(42, 16, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 09:49:39', '', '2020-01-01 09:49:39'),
(43, 17, NULL, NULL, '', '', 'Absent', '', NULL, '', '2020-01-01 09:49:39', '', '2020-01-01 09:49:39'),
(44, 18, NULL, NULL, '', '', 'Absent', '', NULL, '', '2020-01-01 09:49:39', '', '2020-01-01 09:49:39'),
(45, 19, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 09:49:40', '', '2020-01-01 09:49:40'),
(46, 16, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 09:50:05', '', '2020-01-01 09:50:05'),
(47, 17, NULL, NULL, '', '', 'Absent', '', NULL, '', '2020-01-01 09:50:05', '', '2020-01-01 09:50:05'),
(48, 18, NULL, NULL, '', '', 'Absent', '', NULL, '', '2020-01-01 09:50:05', '', '2020-01-01 09:50:05'),
(49, 19, NULL, NULL, '', '', 'Present', '', NULL, '', '2020-01-01 09:50:05', '', '2020-01-01 09:50:05');

-- --------------------------------------------------------

--
-- Table structure for table `lea`
--

CREATE TABLE `lea` (
  `lid` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `course` varchar(100) DEFAULT NULL,
  `batch` varchar(100) DEFAULT NULL,
  `fromdate` date DEFAULT NULL,
  `todate` date DEFAULT NULL,
  `reason` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lea`
--

INSERT INTO `lea` (`lid`, `name`, `course`, `batch`, `fromdate`, `todate`, `reason`) VALUES
(NULL, 'Ebin', 'Jsd', '2018', '2020-01-04', '2020-01-04', 'marrige function'),
(NULL, 'asna', 'Jsd', '2018', '2020-01-10', '2020-01-10', 'marrige fuction');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `Name` varchar(30) DEFAULT NULL,
  `Dateofbirth` date DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Mobile` varchar(50) DEFAULT NULL,
  `Gender` varchar(50) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `Doj` date DEFAULT NULL,
  `Doc` date DEFAULT NULL,
  `Qualification` varchar(50) DEFAULT NULL,
  `Username` varchar(30) DEFAULT NULL,
  `Password` varchar(3) DEFAULT NULL,
  `Types` varchar(3) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` varchar(90) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` varchar(90) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `rltn` varchar(10) DEFAULT NULL,
  `Class` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `Name`, `Dateofbirth`, `Email`, `Mobile`, `Gender`, `Address`, `Doj`, `Doc`, `Qualification`, `Username`, `Password`, `Types`, `created_at`, `created_by`, `updated_at`, `updated_by`, `is_active`, `rltn`, `Class`) VALUES
(16, 'Asna J', '1997-08-08', 'asmaimu@gmail.com', '7356082863', 'female', 'kazhakuttom', '0000-00-00', '0000-00-00', 'BSC STATISTICS', 'Asna', 'asn', 'stu', '2020-01-01 08:39:35', NULL, '2020-01-01 08:39:35', NULL, NULL, NULL, 'JSD'),
(17, 'Arya A', '1997-01-04', 'arya@gmail.com', '9995035044', 'female', 'kollam', '0000-00-00', '0000-00-00', 'B tech', 'Arya', 'ary', 'stu', '2020-01-01 08:41:31', NULL, '2020-01-01 08:41:31', NULL, NULL, NULL, 'JSD2'),
(18, 'Ashish Babu', '1995-01-31', 'ashish@gmail.com', '9876543210', 'female', 'kottayam', '0000-00-00', '0000-00-00', 'B tech', 'ashish', 'ash', 'stu', '2020-01-01 08:43:09', NULL, '2020-01-01 08:43:09', NULL, NULL, NULL, 'JSD'),
(19, 'Sebastian I', '2020-01-18', 'sebastian@gmail.com', '9632587410', 'male', 'kottayam', '0000-00-00', '0000-00-00', 'B tech', 'sebastian', 'seb', 'stu', '2020-01-01 08:45:00', NULL, '2020-01-01 08:45:00', NULL, NULL, NULL, 'JSD2'),
(20, 'admin', '2020-01-03', 'admin@gmail.com', '0147852369', 'female', 'orisys', '0000-00-00', '0000-00-00', 'B tech', 'admin', 'adm', 'adm', '2020-01-01 09:30:46', NULL, '2020-01-01 09:30:46', NULL, NULL, NULL, ''),
(21, 'Gana K', '1991-01-10', 'gana@gmail.com', '9876543210', 'female', 'kannur', NULL, NULL, 'MSc', 'gana', 'gan', 'tea', '2020-01-01 08:58:17', NULL, '2020-01-01 08:58:17', NULL, NULL, NULL, NULL),
(22, 'Vijith V', '1992-12-22', 'vijith@gmail.com', '7025791184', 'male', 'kozhikode', NULL, NULL, 'MSc', 'vijith', 'vij', 'tea', '2020-01-01 08:59:49', NULL, '2020-01-01 08:59:49', NULL, NULL, NULL, NULL),
(23, 'Jumaila Beevi S', NULL, 'jumaila@gmail.com', '9995035044', NULL, 'kazhakuttom', NULL, NULL, NULL, NULL, 'jum', 'par', '2020-01-01 09:00:46', NULL, '2020-01-01 09:00:46', NULL, NULL, 'Mother', NULL),
(24, 'Subash B', NULL, 'subash@gmail.com', '8129669525', NULL, 'kollam', NULL, NULL, NULL, NULL, 'sub', 'par', '2020-01-01 09:03:05', NULL, '2020-01-01 09:03:05', NULL, NULL, 'Father', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendence`
--
ALTER TABLE `attendence`
  ADD PRIMARY KEY (`atten_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendence`
--
ALTER TABLE `attendence`
  MODIFY `atten_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

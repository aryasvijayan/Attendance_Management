<!--Author-ARYA-->
<?php require "templates/header.php"; ?>
<h1><center>Attendence</center></h1>
<div class="att">
<center>
<ul>
<li><center><a href= "attendance_jsd.php">JSD1</a></li>
<li><center><a href= "attendance_jsd2.php">JSD2</a></li>
<li><center><a href= "attendance_ui.php">UI</a></li>
<li><center><a href= "attendance_ed.php">ED</a></li>
</ul>
</center>
</div>
<?php require "templates/footer.php"; ?>
CREATE DATABASE try;

use try;

CREATE TABLE users(
	id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
	
	Name VARCHAR(30) ,
	Dateofbirth VARCHAR(50) ,
	Email VARCHAR(50) ,
    Mobile VARCHAR(50) ,
	Gender VARCHAR(50),
	Address VARCHAR(50),
	Doj DATE,
	Doc DATE,
	Qualification VARCHAR(50) ,
	Username VARCHAR(30),
	Password VARCHAR(3),
	Types VARCHAR(3),
	created_at TIMESTAMP,
	created_by VARCHAR(90), 
	updated_at TIMESTAMP,
	updated_by VARCHAR(90), 
    is_active BOOLEAN,
	rltn VARCHAR(10)
);
CREATE TABLE attendence (
	atten_id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
	id INT(11),
	batch_id INT(11),
	class_id INT(11),
	tdate VARCHAR(80) NOT NULL,
	afternoon VARCHAR(40) NOT NULL,
	fornoon VARCHAR(40) NOT NULL,
	status VARCHAR(40) NOT NULL,
	sub_id INT(11),
	created_by VARCHAR(80) NOT NULL,
	created_at TIMESTAMP,
	updated_by VARCHAR(80) NOT NULL,
	updated_at TIMESTAMP NOT NULL DEFAULT NOW() ON UPDATE NOW()
);
CREATE TABLE att(
    name VARCHAR(40),
	afternoon VARCHAR(40) ,
	fornoon VARCHAR(40)
	
CREATE TABLE att1(
    name VARCHAR(40),
	afternoon VARCHAR(40) ,
	fornoon VARCHAR(40),
	created_at TIMESTAMPs
);
